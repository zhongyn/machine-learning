
import numpy as np

def featureCount(data, label, groups, voca):

	# Initial feature vectors of each label for Bernoulli and Multinomial models
	berVectors = np.zeros((groups,voca))
	mulVectors = np.zeros((groups,voca))

	# Bernoulli: Count the number of docs containing word i for each label
	# Multinomial: Count the number of word i for each label
	for index, item in enumerate(data):
		lab = label[item[0]-1]
		word = item[1]
		berVectors[lab-1, word-1] += 1
		mulVectors[lab-1, word-1] += item[2]

	return [berVectors, mulVectors]


def berFeatGen(data, voca):

	# Generate feature vector of each document
	docID = np.unique(data[:,0])
	numDocs = len(docID)
	berFeature = np.zeros((numDocs,voca))

	# Bernoulli: add the presence of word i for each doc
	# Multinomial: Count the number of word i for each doc
	for index, item in enumerate(data):
		docId = item[0]-1
		wordId = item[1]-1
		berFeature[docId, wordId] = 1

	return berFeature

def mulFeatGen(data, voca):

	# Generate feature vector of each document
	docID = np.unique(data[:,0])
	numDocs = len(docID)
	mulFeature = np.zeros((numDocs,voca))

	# Bernoulli: add the presence of word i for each doc
	# Multinomial: Count the number of word i for each doc
	for index, item in enumerate(data):
		docId = item[0]-1
		wordId = item[1]-1
		mulFeature[docId, wordId] = item[2]

	return mulFeature

