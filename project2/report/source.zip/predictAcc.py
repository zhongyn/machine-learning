import numpy as np

predictBer = np.load("predictBer.npy")
predictMul = np.load("predictMul.npy")

testLabel = np.loadtxt("../data/test.label", delimiter=' ', dtype=int)
numDocs = len(testLabel)

corrBer = testLabel - predictBer
corrMul = testLabel - predictMul

berAcc = 1.0*len(corrBer[corrBer==0])/numDocs
mulAcc = 1.0*len(corrMul[corrMul==0])/numDocs

print "berAcc = " + str(berAcc) + "; mulAcc = " + str(mulAcc)